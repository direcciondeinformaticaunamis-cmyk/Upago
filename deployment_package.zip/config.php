<?php
/**
 * Configuración de la aplicación UNAMIS - Upago
 * NO incluir este archivo en repositorios públicos (está en .gitignore)
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'u876493207_upagobd');
define('DB_USER', 'u876493207_userupago');
define('DB_PASS', '17080602Diu26*');

define('ADMIN_USER',  'admin@unamis.edu.py');
define('ADMIN_PASS',  '17080602Diu26$');
define('JWT_SECRET',  '854fd509c152425c1b9f9eab4d8bc1c5645d48a8ed19385a0c55d28afc05147c0b03a50352f3658c3f2dd4f370046');


define('UPLOAD_BASE', 'uploads/');
define('MAX_FILE_SIZE', 5242880); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'pdf']);

$upload_folders = [
    "cedula"     => "cedulas/",
    "nacimiento" => "nacimientos/",
    "titulo"     => "titulos/",
    "estudio"    => "certificados/",
    "foto"       => "fotos/",
    "otro"       => "otros/"
];
